import React from 'react';


const QuizHeader = () => {
    return (
        <div className='sticky-top'>
        <nav className="navbar navbar-light bg-light">
             <h6 className="navbar-brand">Quiz App</h6>
           
         </nav>
     </div>
    );
};

export default QuizHeader;