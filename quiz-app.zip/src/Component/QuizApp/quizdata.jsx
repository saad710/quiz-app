export const quizContent = [
    {
        id: 100,
        question: 'Martha ,Mary, May, Made Marvelous Milk. In that sentence who made the milk? This is an easy and dumb question!',
        options: [
            {
                id: 1,
                option: 'Martha',
                queId : 100,
		        score: 15,
            },
            {
                id: 2,
                option: 'Mary',
                queId : 100,
                score: 10,
            },
            {
                id: 3,
                option: 'Martha, Mary, May',
                queId : 100,
                score: 5,
            },
        ],

    },

{
        id: 200,
        question: 'Martha ,Mary, May, Made Marvelous Milk. In that sentence who made the milk? This is an easy and dumb question!',
        options: [
            {
                id: 4,
                option: 'yyyy',
		        score: 10,
            },
            {
                id: 5,
                option: 'ppp',
                score: 5,
            },
            {
                id: 6,
                option: 'tttt',
                score:0
            },
        ],

    },

    {
        id: 300,
        question: 'Martha ,Mary, May, Made Marvelous Milk. In that sentence who made the milk? This is an easy and dumb question!',
        options: [
            {
                id: 7,
                option: 'dddd',
		        score: 20,
            },
            {
                id: 8,
                option: 'bbbb',
                score: 25,
            },
            {
                id: 9,
                option: 'kkkk',
                score:0
            },
        ],

    },
    
    

];





// const [score, setScore] = useState([]) // all score

// const [currentQus, setCurrentQus] = useState("")
// const [currentQusScore, setCurrentSCore] = useState("") // cureent


// if(currentQus === indx+1) {
	
// }